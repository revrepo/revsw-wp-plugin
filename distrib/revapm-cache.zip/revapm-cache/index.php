<?php
die; // prevent from external access