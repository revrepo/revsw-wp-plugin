<?php

function mcrevapm_get_page_curl($url, $custom_header = null,  $timeout = 30, $cookie="", $referrer="", $proxy="", $retry=1) {
if (defined("MCREVAPM_DEBUG_CURL")) mcrevapm_log(">mcrevapm_get_page_curl url:\n$url\nHeader:\n".print_r($custom_header,true));
//    $proxy = "127.0.0.1:8888";
	$s = "";
	if ($curl = curl_init()) {
		$retry--;
		$agent = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0";
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl,CURLOPT_ENCODING , "gzip");
		curl_setopt($curl, CURLOPT_USERAGENT, $agent);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
//		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($curl, CURLOPT_TIMEOUT, $timeout);
		curl_setopt($curl, CURLOPT_MAXREDIRS, 5);
		curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie);
		curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie);
//            curl_setopt($curl, CURLOPT_ENCODING, 'gzip');
		if (strlen($proxy) > 0)
			curl_setopt($curl, CURLOPT_PROXY, $proxy);

		if (strlen($referrer) > 0)
			curl_setopt($curl, CURLOPT_REFERER, $referrer);

		if (strncasecmp($url, "https", 5) == 0) {
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
		}
		if (is_array($custom_header)) {
			curl_setopt($curl, CURLOPT_HTTPHEADER, $custom_header);
		}
		$s = curl_exec($curl);
/*
		if($errno = curl_errno($curl)) {
        $error_message = curl_strerror($errno);
        echo "cURL error ({$errno}):\n {$error_message}";
		}
*/
		$code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
if (defined("MCREVAPM_DEBUG_CURL")) mcrevapm_log("<mcrevapm_get_page_curl $code url:\n$url\n$s");

		if (strlen($s) <= 0) {
			return $code;
		}

//die("aaa $url status code = ".);
		curl_close($curl);
	}
	return $s;
}


function mcrevapm_post_json_curl($url, $method = "PUT", $params = "{}",  $custom_header = null, $timeout = 30, $cookie="", $referrer="", $proxy="", $retry=1) {
//    $proxy = "127.0.0.1:8888";
	$s = "";
	if ($curl = curl_init()) {
		$retry--;
		$agent = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0";
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl,CURLOPT_ENCODING , "gzip");
		curl_setopt($curl, CURLOPT_USERAGENT, $agent);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
//		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($curl, CURLOPT_TIMEOUT, $timeout);
		curl_setopt($curl, CURLOPT_MAXREDIRS, 5);
		$headers = ($custom_header) ? $custom_header : array();
		if ($method != "GET") {
			if (is_array($params) && ($method == "POST")) {
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $params);
			} else {
				curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
				curl_setopt($curl, CURLOPT_POSTFIELDS, $params);  //Post Fields
				$headers[] = 'Accept: application/json';
				$headers[] = 'Content-Type: application/json';
				$headers[] = 'Content-Length: ' . strlen($params);
			}
		} else {
			$headers[] = "Accept: application/json";
		}
		if (count($headers) > 0)
			curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie);
		curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie);
//            curl_setopt($curl, CURLOPT_ENCODING, 'gzip');
		if (strlen($proxy) > 0)
			curl_setopt($curl, CURLOPT_PROXY, $proxy);

		if (strlen($referrer) > 0)
			curl_setopt($curl, CURLOPT_REFERER, $referrer);

		if (strncasecmp($url, "https", 5) == 0) {
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
		}
//		curl_setopt($curl, CURLOPT_USERPWD, $tl_email.":".$tl_key);
		$s = curl_exec($curl);
/*
		if($errno = curl_errno($curl)) {
        $error_message = curl_strerror($errno);
        echo "cURL error ({$errno}):\n {$error_message}";
		}
*/
		if (strlen($s) <= 0) {
			$code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
			return $code;
		}

//die("aaa $url status code = ".);
		curl_close($curl);
	}
	return $s;
}
