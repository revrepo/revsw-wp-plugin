<?php

require_once MCREVAPM_PLUGIN_DIR."inc/functions.php";

class MCREVAPM_API {

	protected $config;

	public function __construct(){
		if (!current_user_can("manage_options")) die ("Access denied");
		$this->config = array(
			"API_URL" => "https://api.revapm.net/v1/",
			"DEFAULT_API_KEY" => "b4eaa8e1-514c-4189-be67-b6c33eb2f7ed",
			"BILLNG_URL" => "billing_plans",
			"AUTH_EMAIL_PASS_URL" => "authenticate",
			"GET_USER_URL" => "users/myself",
			"API_KEYS_URL" => "api_keys",
			"API_KEYS_MYSELF_URL" => "api_keys/myself",
			"DOMAINS_URL" => "domain_configs",
			"GET_LOCATIONS_URL" => "locations/firstmile",
			"SIGNUP_URL" => "signup2?email=[email]",
			"SIGNUP_JSON" => '{"billing_plan":"[billing-plan]","country":"US","password":"[password]","email":"[email]","first_name":"[fname]","last_name":"[lname]"}'
		);
	}

	protected function json_header(){
		header('Cache-Control: no-cache, must-revalidate');
		header('Expires: Thu, 1 Jan 1970 00:00:00 GMT');
		header('Content-Type: application/json');
	}

	protected function auth_by_email_pass($email,$password){
		$url = $this->config["API_URL"] . $this->config["AUTH_EMAIL_PASS_URL"];
		$ar = array(
			"email" => $email,
			"password" => $password
		);
if (defined("MCREVAPM_DEBUG")) mcrevapm_log(">auth_by_email_pass\n$url\n".print_r($ar,true));
		$s = mcrevapm_post_json_curl($url,"POST",$ar);
		$ar = @json_decode($s,true);
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("1.auth_by_email_pass\n$s\n".print_r($ar,true));
		$res = ((int)@$ar["statusCode"] == 200) ? $ar["token"] : "";
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<auth_by_email_pass Result token:\n$res");
		return $res;
	}

	protected function get_auth_header_by_token($token) {
		return "authorization:Bearer ".$token;
	}

	protected function get_auth_header_by_key($api_key) {
		return "authorization:X-API-KEY ".$api_key;
	}

	protected function get_user_info_by_token($token){
		$url = $this->config["API_URL"] . $this->config["GET_USER_URL"];
if (defined("MCREVAPM_DEBUG")) mcrevapm_log(">get_user_info token = $token\n$url");
		$s = mcrevapm_get_page_curl($url,array( $this->get_auth_header_by_token($token) ));
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<get_user_info token = $token\n$url\n$s");
		return @json_decode($s,true);
	}

	protected function get_user_info_by_key($api_key){
		$url = $this->config["API_URL"] . $this->config["API_KEYS_MYSELF_URL"];
if (defined("MCREVAPM_DEBUG")) mcrevapm_log(">get_user_info_by_api_key key = $api_key\n$url");
		$s = mcrevapm_get_page_curl($url,array( $this->get_auth_header_by_key($api_key) ));
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<get_user_info_by_api_key key = $api_key\n$url\n$s");
		return @json_decode($s,true);
	}

	public function get_api_key($email,$password){
		$this->json_header();
if (defined("MCREVAPM_DEBUG")) mcrevapm_log(">get_api_key email = $email password = $password");
		$token = $this->auth_by_email_pass($email,$password);
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("1.get_api_key email = $email password = $password token = $token");
		if (strlen($token) <= 0) {
			$s = '{"statusCode":0,"message":"Invalid email or password or account is not active."}';
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<get_api_key\n".$s);
			return $s;
		}
		// get user info
		$ar_user = $this->get_user_info_by_token($token);
		if (strlen(@$ar_user["user_id"] < 10)) {
			$s = '{"statusCode":0,"message":"Invalid users/myself response"}';
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<get_api_key\n".$s);
			return $s;
		}
		$account_id = @$ar_user["companyId"][0];
		$request = '{"account_id":"'.$account_id.'"}';
		$url = $this->config["API_URL"] . $this->config["API_KEYS_URL"];
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("2.get_api_key email = $email password = $password token = $token\n$url\n$request");
		$s = mcrevapm_post_json_curl($url,"POST",$request,array( $this->get_auth_header_by_token($token) ));
		$ar = json_decode($s,true);
		if ((int)$ar["statusCode"] == 200) {
			$s1 = trim(@get_option("mcrevapm_settings"));
			$ar_settings = json_decode($s1,true);
			$ar_settings["api_key"] = $ar["key"];
			update_option("mcrevapm_settings",json_encode($ar_settings));
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("3.get_api_key settings:\n".print_r($ar_settings,true));
		}
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<get_api_key\n".$s);
		return $s;
	}

	public function get_billing_plans(){
		$url = $this->config["API_URL"] . $this->config["BILLNG_URL"];
if (defined("MCREVAPM_DEBUG")) mcrevapm_log(">get_billing_plans\n$url");
		$s = mcrevapm_get_page_curl($url);
		$ar = @json_decode($s,true);
		$ar_sorted = array();
		while (count($ar) > 0) {
			// find item with minimum monthly price from source array
			$found_idx = -1;
			$min_price = -1;
			foreach ($ar as $idx => $item) {
				$price = (float)@$item["monthly_fee"];
				if (($min_price < 0) || ($price < $min_price)) {
					$found_idx = $idx;
					$min_price = $price;
				}
			}
			if ($found_idx < 0) break;
			$key = $ar[ $found_idx ][ "chargify_handle" ];
			foreach ($ar[ $found_idx ][ "services" ] as $idx =>  $ar_service) {
				$ar[ $found_idx ][ "services" ][ $idx ][ "cost" ] = sprintf("%0.2f", (float)@$ar_service[ "cost" ]);
			}
			$ar_sorted[ $key ] = $ar[ $found_idx ];
			// remove element from old array
			array_splice($ar,$found_idx,1);
		}
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<get_billing_plans\n".print_r($ar,true));
		return json_encode($ar_sorted);
	}

	public function signup($data){
if (defined("MCREVAPM_DEBUG")) mcrevapm_log(">signup\n".print_r($data,true));
		$this->json_header();
		$billing_plan = trim(@$data["mcrevapm_plan"]);
		$email = trim(@$data["mcrevapm_email"]);
		if ((strlen($email) < 7) || (stripos($email,"@") === false) || (stripos($email,".") === false)) {
			$s = '{"statusCode":0,"message":"Invalid email address. Please use another email address."}';
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<signup\n".$s);
			return $s;
		}
		$fname = trim(@$data["mcrevapm_fname"]);
		if (strlen($fname) < 1) {
			$s = '{"statusCode":0,"message":"First name is empty."}';
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<signup\n".$s);
			return $s;
		}
		$lname = trim($data["mcrevapm_lname"]);
		if (strlen($lname) < 1) {
			$s = '{"statusCode":0,"message":"Last name is empty."}';
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<signup\n".$s);
			return $s;
		}
		$password = @$data["mcrevapm_pass"];
		if (strlen($password) < 8) {
			$s = '{"statusCode":0,"message":"Password too short - must be at least 8 characters."}';
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<signup\n".$s);
			return $s;
		}
		$url = $this->config["API_URL"] . str_replace("[email]",urlencode($email),$this->config["SIGNUP_URL"]);
		$json = str_replace(
					array("[billing-plan]","[password]","[email]","[fname]","[lname]"),
					array($billing_plan,$password,$email,$fname,$lname),
					$this->config["SIGNUP_JSON"]
		);
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("1.signup POST\n".$url."\n".$json);
		$s = mcrevapm_post_json_curl($url,"POST",$json);
		$res = @json_decode($s,true);
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("2.signup POST\n".print_r($res,true));
		$status_code = (int)@$res["statusCode"];
		if (($status_code >= 200) && ($status_code < 300))  {
			$res["statusCode"] = 200;
			$res["message"] = $res["message"]."<br/>Please, check your mailbox. You should receive an email with account activation link and open it in browser.<br/>After that click button Get API Key to generate your API key.";
			$ar_settings = @json_decode(get_option("mcrevapm_settings"),true);
			$ar_settings["account_status"] = "registered";
			$ar_settings["account_email"] = $email;
			$ar_settings["account_password"] = base64_encode($password);
//			$ar_settings["account_data"] = json_decode($json,true);
//			$ar_settings["account_response"] = $res;
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("3.signup new settings\n".print_r($ar_settings,true));
			update_option("mcrevapm_settings",json_encode($ar_settings));
		}
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<signup\n".json_encode($res));
		return json_encode($res);
		//{"statusCode":501,"error":"Not Implemented","message":"User with email address infinity-ex@narod.ru already exists. Please use another email address."}
	}

	public function get_domains($api_key,$output="json") {
if (defined("MCREVAPM_DEBUG")) mcrevapm_log(">get_domains api_key = $api_key, output = $output");
		$res = array();
		if (strlen($api_key) > 0) {
			$url = $this->config["API_URL"] . $this->config["DOMAINS_URL"];
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("1.get_domains api_key = $api_key, output = $output\n$url");
			$s = mcrevapm_get_page_curl($url,array( $this->get_auth_header_by_key($api_key) ));
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("2.get_domains api_key = $api_key, output = $output\n$s");
			$res = json_decode($s,true);
			if (!is_array($res))
				$res = array();
		}
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<get_domains api_key = $api_key, output = $output\n".print_r($res,true));
		if ($output == "json") {
			$this->json_header();
			return json_encode($res);
		} else
			return $res;
	}

	public function set_api_key($api_key) {
		$this->json_header();
		$url = $this->config["API_URL"] . $this->config["DOMAINS_URL"];
if (defined("MCREVAPM_DEBUG")) mcrevapm_log(">set_api_key api_key = $api_key\n$url");
		$s = mcrevapm_get_page_curl($url,array( $this->get_auth_header_by_key($api_key) ));
		$ar = @json_decode($s,true);
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("1.set_api_key $api_key\n$s\n".print_r($ar,true));
		if ((int)@$ar["statusCode"] >= 400) {
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<set_api_key ERROR $api_key\n$s\n".print_r($ar,true));
			return json_encode($ar);
		}
		// update settings
		$ar_settings = @json_decode(get_option("mcrevapm_settings"),true);
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("2.set_api_key $api_key\n".print_r($ar_settings,true));
		$ar_settings["api_key"] = $api_key;
		$ar_settings["cdn_status"] = "off";
		update_option("mcrevapm_settings",json_encode($ar_settings));
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("3.set_api_key $api_key\n".print_r($ar_settings,true));
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<set_api_key OK $api_key\n".print_r($ar,true));
		return json_encode(array("statusCode" => 200, "data" => $ar));
	}

	public function get_locations(){
		$url = $this->config["API_URL"] . $this->config["GET_LOCATIONS_URL"];
if (defined("MCREVAPM_DEBUG")) mcrevapm_log(">get_locations\n$url");
		$s = mcrevapm_get_page_curl($url, array( $this->get_auth_header_by_key($this->config[ "DEFAULT_API_KEY" ]) ));
		$ar = json_decode($s,true);
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("1.get_locations\n".print_r($ar,true));
		$res = '<option value="">Select Location...</option>';
		if (count($ar) > 0) {
			foreach($ar as $loc) {
				$res .= '<option value="'.$loc["id"].'">'.$loc["locationName"]."</option>";
			}
		}
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<get_locations\n$res");
		return $res;
	}

	public function add_domain($domain,$server,$header,$location) {
		$this->json_header();
		$ar_settings = @json_decode(get_option("mcrevapm_settings"),true);
		$api_key = @$ar_settings["api_key"];
		$url = $this->config["API_URL"] . $this->config["DOMAINS_URL"];
if (defined("MCREVAPM_DEBUG")) mcrevapm_log(">add_domain domain = $domain, server = $server, header = $header, location = $location\n$url\n".print_r($ar_settings,true));
		// get user info
		$ar_key = $this->get_user_info_by_key($api_key);
		if (strlen(@$ar_key["id"] < 10)) {
			$s = '{"statusCode":0,"message":"Invalid api_keys/myself response"}';
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<add_domain\n".$s);
			return $s;
		}
		$account_id = @$ar_key["account_id"];
		$request = json_encode(
			array(
				"domain_name" => $domain,
				"account_id" => $account_id,
				"origin_server" => $server,
				"origin_host_header" => $header,
				"origin_server_location_id" => $location
			)
		);
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("1.add_domain request:\n".$request);
		$s = mcrevapm_post_json_curl($url,"POST",$request,array( $this->get_auth_header_by_key($api_key) ));
/*
		$ar = json_decode($s,true);
		if ((int)$ar["statusCode"] == 200) {

		}
*/
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<add_domain\n".$s);
		return $s;
	}

	public function delete_domain($id){
		$this->json_header();
		$ar_settings = @json_decode(get_option("mcrevapm_settings"),true);
		$api_key = @$ar_settings["api_key"];
		$url = $this->config["API_URL"] . $this->config["DOMAINS_URL"]."/".$id;
if (defined("MCREVAPM_DEBUG")) mcrevapm_log(">delete_domain id = $id\n$url\n".print_r($ar_settings,true));
		$s = mcrevapm_post_json_curl($url,"DELETE","",array( $this->get_auth_header_by_key($api_key) ));
		$ar = @json_decode($s,true);
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("1.auth_by_email_pass\n$s\n".print_r($ar,true));
		if ((int)@$ar["statusCode"] == 202) {
			$ar["statusCode"] = 200;
			if (@$ar_settings["domain_id"] == $id) {
				// delete active domain
				$ar_settings["domain_id"] = $ar_settings["domain_name"] = $ar_settings["domain_server"] = $ar_settings["domain_cname"] = "";
				update_option("mcrevapm_settings",json_encode($ar_settings));
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("2.delete_domain id = $id\n$url\n".print_r($ar_settings,true));
			}
		}
		$s = json_encode($ar);
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<delete_domain id = $id\n".$s);
		return $s;
	}
};
