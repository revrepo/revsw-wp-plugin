<?php

require_once MCREVAPM_PLUGIN_DIR."inc/functions.php";

class MCREVAPM_API {

	protected $config;

	public function __construct(){
		$this->config = array(
			"API_URL" => "https://api.revapm.net/v1/",
			"SIGNUP_URL" => "signup2?email=[email]",
			"SIGNUP_JSON" => '{"billing_plan":"billing-plan-[billing-plan]","country":"US","password":"[password]","email":"[email]","first_name":"[fname]","last_name":"[lname]"}'
		);
	}

	protected function json_header(){
		header('Cache-Control: no-cache, must-revalidate');
		header('Expires: Thu, 1 Jan 1970 00:00:00 GMT');
		header('Content-Type: application/json');
	}

	public function signup(){
if (defined("MCREVAPM_DEBUG")) mcrevapm_log(">signup\n".@file_get_contents("php://input"));
		$this->json_header();
		$data = @json_decode(file_get_contents("php://input"),true);
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("0.signup\n".print_r($data,true));
		$billing_plan = trim(@$data["mcrevapm_plan"]);
		$email = trim(@$data["mcrevapm_email"]);
		if ((strlen($email) < 7) || (stripos($email,"@") === false) || (stripos($email,".") === false)) {
			$s = '{"statusCode":0,"message":"Invalid email address. Please use another email address."}';
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<signup\n".$s);
			return $s;
		}
		$fname = trim(@$data["mcrevapm_fname"]);
		if (strlen($fname) < 1) {
			$s = '{"statusCode":0,"message":"First name is empty."}';
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<signup\n".$s);
			return $s;
		}
		$lname = trim($data["mcrevapm_lname"]);
		if (strlen($lname) < 1) {
			$s = '{"statusCode":0,"message":"Last name is empty."}';
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<signup\n".$s);
			return $s;
		}
		$password = @$data["mcrevapm_pass"];
		if (strlen($password) < 8) {
			$s = '{"statusCode":0,"message":"Password too short - must be at least 8 characters."}';
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<signup\n".$s);
			return $s;
		}
		$url = $this->config["API_URL"] . str_replace("[email]",urlencode($email),$this->config["SIGNUP_URL"]);
		$json = str_replace(
					array("[billing-plan]","[password]","[email]","[fname]","[lname]"),
					array($billing_plan,$password,$email,$fname,$lname),
					$this->config["SIGNUP_JSON"]
		);
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("1.signup POST\n".$url."\n".$json);
		$s = mcrevapm_post_json_curl($url,"POST",$json);
		$res = @json_decode($s,true);
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("2.signup POST\n".print_r($res,true));
		$status_code = (int)@$res["statusCode"];
		if (($status_code >= 200) && ($status_code < 300))  {
			$res["statusCode"] = 200;
			$res["message"] .= "<br/>Please, check your mailbox. You should receive an email with account activation link and open it in browser. <br/>Click button below to generate your API key.";
			$ar_settings = @json_decode(get_option("mcrevapm_settings"),true);
			$ar_settings["account_status"] = "registered";
			$ar_settings["account_data"] = json_decode($json,true);
			$ar_settings["account_response"] = $res;
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("3.signup new settings\n".print_r($ar_settings,true));
			update_option("mcrevapm_settings",json_encode($ar_settings));
		}
if (defined("MCREVAPM_DEBUG")) mcrevapm_log("<signup\n".json_encode($res));
		return json_encode($res);
		//{"statusCode":501,"error":"Not Implemented","message":"User with email address infinity-ex@narod.ru already exists. Please use another email address."}
	}

};
