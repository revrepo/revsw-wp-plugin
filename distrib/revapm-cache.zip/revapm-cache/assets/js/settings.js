function mcrevapm_save_settings(){

}

function mcrevapm_create_account(){

}

function mcrevapm_purge_all(){

}

jQuery(document).ready(function(){
console.log("ready settings page");
	  jQuery("#mcrevapm_tabs").tabs({
        "active": "mcrevapm_tab1"
    });
		jQuery("#mcrevapm_settings_div").show();

});