<?php
?>
					<h3>Here will be account settings</h3>
					<ul id="mcrevapm_signup">
						<li>
								<div class="mcrevapm_w100p">
									<label>Account type:</label>
									<select id="mcrevapm_plan" required="required">
										<option value="developer" selected="selected">Developer $5/mon</option>
										<option value="bronze">Bronze $150/mon</option>
										<option value="silver">Silver $350/mon</option>
										<option value="gold">Gold $799/mon</option>
									</select>
								</div>

								<div class="mcrevapm_plan_developer mcrevapm_w100p mcrevapm_plan ">
									<h3 class="mcrevapm_orange">$5/mon</h3>
									<div>
										Provides you with 100GB of web or mobile app traffic and 0.5M requests per month, 2 apps, 2 web domains, 1 wildcard SSL name, global network coverage, traffic analytics
									</div>
									<h3>Overage Charges</h3>
									<div class="mcrevapm_plan_prices">
										$10.00 per Mobile App
										<br/>
										$12.00 per Web Domain
										<br/>
										$0.20 per GB of Traffic
										<br/>
										$0.01 per 10K Requests
										<br/>
										$20.00 per SSL Name
									</div>
								</div>

								<div class="mcrevapm_plan_bronze mcrevapm_w100p mcrevapm_plan mcrevapm_hidden">
									<h3 class="mcrevapm_orange">$150/mon</h3>
									<div>
										Provides you with 1TB of web or mobile app traffic and 1M requests per month, 5 apps, 5 web domains, 2 wildcard SSL names, global network coverage, traffic analytics
									</div>
									<h3>Overage Charges</h3>
									<div class="mcrevapm_plan_prices">
										$10.00 per Mobile App
										<br/>
										$12.00 per Web Domain
										<br/>
										$0.10 per GB of Traffic
										<br/>
										$0.01 per 10K Requests
										<br/>
										$20.00 per SSL Name
									</div>
								</div>

								<div class="mcrevapm_plan_silver mcrevapm_w100p mcrevapm_plan mcrevapm_hidden">
									<h3 class="mcrevapm_orange">$350/mon</h3>
									<div>
										Provides you with 5TB of web or mobile app traffic and 5M requests per month, 10 apps, 10 web domains, 3 wildcard SSL names, global network coverage, traffic analytics
									</div>
									<h3>Overage Charges</h3>
									<div class="mcrevapm_plan_prices">
										$10.00 per Mobile App
										<br/>
										$12.00 per Web Domain
										<br/>
										$0.08 per GB of Traffic
										<br/>
										$0.01 per 10K Requests
										<br/>
										$20.00 per SSL Name
									</div>
								</div>

								<div class="mcrevapm_plan_gold mcrevapm_w100p mcrevapm_plan mcrevapm_hidden">
									<h3 class="mcrevapm_orange">$799/mon</h3>
									<div>
										Provides you with 10TB of web or mobile app traffic and 10M requests per month, 20 apps, 20 web domains, 5 wildcard SSL names, global network coverage, traffic analytics									</div>
									<h3>Overage Charges</h3>
									<div class="mcrevapm_plan_prices">
										$10.00 per Mobile App
										<br/>
										$12.00 per Web Domain
										<br/>
										$0.06 per GB of Traffic
										<br/>
										$0.01 per 10K Requests
										<br/>
										$20.00 per SSL Name
									</div>
								</div>

						</li>
						<li><label>Email:</label><input type="email" id="mcrevapm_email" required="required"/></li>
						<li><label>First name:</label><input type="text" id="mcrevapm_fname" required="required"/></li>
						<li><label>Last name:</label><input type="text" id="mcrevapm_lname" required="required"/></li>
						<li><label>Password</label><input type="password" id="mcrevapm_pass" required="required" /></li>
						<li>&nbsp;</li>
						<li>
							<button type="button" onclick="mcrevapm_create_account(this)" class="mcrevapm_orange_button">
								<span class="mcrevapm_fleft">Create Account</span>
								<span class="mcrevapm_spinner mcrevapm_hidden">
									<img src="<?=MCREVAPM_PLUGIN_URL?>assets/img/ajax_loader.gif" class="mcrevapm_loading_img_btn" />
								</span>
							</button>
							<button type="button" onclick="mcrevapm_get_api_key(this)" class="mcrevapm_orange_button mcrevapm_hidden">
									<span class="mcrevapm_fleft">Get API Key</span>
									<span class="mcrevapm_spinner mcrevapm_hidden">
										<img src="<?=MCREVAPM_PLUGIN_URL?>assets/img/ajax_loader.gif" class="mcrevapm_loading_img_btn" />
									</span>
							</button>
						</li>
					</ul>
					<div class="mcrevapm_err mcrevapm_big_font"></div>
					<div class="mcrevapm_ok mcrevapm_big_font"></div>
