<?php
	$user = wp_get_current_user();
	if (!isset($user->ID)) die ("Error - access denied");
	$email = $user->user_email;
	$name = trim($user->display_name);
	$fname = $lname = "";
	if (strlen($name) > 0) {
		if (stripos($name," ") !== false) {
			$ar = explode(" ",$name);
			$lname = $ar[ count($ar)-1 ];
			array_splice($ar,count($ar)-1,1);
			$fname = trim(implode(" ",$ar));
		} else {
			$fname = $name;
		}
	}
	//var_dump($user); die;
?>
					<ul id="mcrevapm_signup">
						<li>
								<div class="mcrevapm_w100p">
									<label>Account type:</label>
									<select id="mcrevapm_plan" required="required"></select>
								</div>

								<div class="mcrevapm_plan_developer mcrevapm_w100p mcrevapm_plan ">
									<h3 class="mcrevapm_orange">$<span class="mcrevapm_plan_price"></span>/mon</h3>
									<div class="mcrevapm_plan_description"></div>
									<h3>Overage Charges</h3>
									<div class="mcrevapm_plan_prices">
										$<span class="mcrevapm_plan_price1"></span> per <span class="mcrevapm_plan_unit1"></span>
										<br/>
										$<span class="mcrevapm_plan_price2"></span> per <span class="mcrevapm_plan_unit2"></span>
										<br/>
										$<span class="mcrevapm_plan_price3"></span> per <span class="mcrevapm_plan_unit3"></span>
										<br/>
										$<span class="mcrevapm_plan_price4"></span> per <span class="mcrevapm_plan_unit4"></span>
										<br/>
										$<span class="mcrevapm_plan_price5"></span> per <span class="mcrevapm_plan_unit5"></span>
									</div>
								</div>

						</li>
						<li><label>Email:</label><input type="email" id="mcrevapm_email" required="required" value="<?=$email?>" /></li>
						<li><label>First name:</label><input type="text" id="mcrevapm_fname" required="required" value="<?=$fname?>" /></li>
						<li><label>Last name:</label><input type="text" id="mcrevapm_lname" required="required"  value="<?=$lname?>" /></li>
						<li><label>Password</label><input type="password" id="mcrevapm_pass" required="required" value="" /></li>
						<li>&nbsp;</li>
						<li>
							<button type="button" onclick="mcrevapm_create_account(this)" class="mcrevapm_orange_button">
								<span class="mcrevapm_fleft">Create Account</span>
								<span class="mcrevapm_spinner mcrevapm_hidden">
									<img src="<?=MCREVAPM_PLUGIN_URL?>assets/img/ajax_loader.gif" class="mcrevapm_loading_img_btn" />
								</span>
							</button>
							<?php
/*
							<button type="button" onclick="mcrevapm_get_api_key(this)" class="mcrevapm_orange_button">
 */
							?>
							<button type="button" onclick="mcrevapm_get_api_key(this)" class="mcrevapm_orange_button mcrevapm_hidden">
									<span class="mcrevapm_fleft">Get API Key</span>
									<span class="mcrevapm_spinner mcrevapm_hidden">
										<img src="<?=MCREVAPM_PLUGIN_URL?>assets/img/ajax_loader.gif" class="mcrevapm_loading_img_btn" />
									</span>
							</button>
						</li>
					</ul>
					<div class="mcrevapm_err mcrevapm_big_font"></div>
					<div class="mcrevapm_ok mcrevapm_big_font"></div>
