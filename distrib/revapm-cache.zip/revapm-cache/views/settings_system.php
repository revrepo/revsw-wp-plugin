<?php
?>
					<ul>
						<li>
							<div id="mcrevapm_api_key_div">
								<label>API key:</label><input type="text"" id="mcrevapm_api_key" value="<?=$ar_settings["api_key"]?>"/>
							</div>
							<div id="mcrevapm_api_key_updating_div" class="mcrevapm_hidden">
								<img src="<?=MCREVAPM_PLUGIN_URL?>assets/img/ajax_loader.gif" />
								<span>Updating API Key, please wait...</span>
							</div>
						</li>
						<li>
							<h3>CDN Domains Available <button class="mcrevapm_orange_button" onclick="mcrevapm_add_domain()">New Domain</button></h3>
							<div>Please, select one of existing domains or create a new domain to use RevAPM CDN</div>
							<table id="mcrevapm_domains_table" width="100%" cellpadding="0.2em" cellspacing="0.2em">
								<thead>
									<tr>
										<th>CDN Domain</th>
										<th>Domain</th>
										<th>Origin Server Name / IP</th>
										<th>Origin Host Header</th>
										<th>Origin Location</th>
										<th>CName</th>
										<th>Operations</th>
									</tr>
								</thead>
								<tbody>
<?php
	foreach ($ar_domains as $d) {
?>
								<tr id="mcrevapm_domain_row_<?=$d["id"]?>" data-id="<?=$d["id"]?>">
									<td><input type="radio" name="mcrevapm_rg_domains" class="mcrevapm_rg_domains" /></td>
									<td><?=$d["domain_name"]?></td>
									<td><?=$d["origin_server"]?></td>
									<td><?=$d["origin_host_header"]?></td>
									<td>&nbsp;</td>
									<td><?=$d["cname"]?></td>
									<td>
<?php /*
										<i class="fa fa-pencil mcrevapm_edit_domain" aria-hidden="true" onclick="mcrevapm_edit_domain(this)" title="Edit Domain"></i>
*/ ?>
										<i class="fa fa-times mcrevapm_delete_domain" aria-hidden="true" onclick="mcrevapm_delete_domain(this)" title="Delete Domain"></i>
									</td>
								</tr>
<?php 
	}
?>								
								</tbody>
							</table>
						</li>
						<li>
							<div id="mcrevapm_cdn_enabled_control_div">
								<input type="checkbox" id="mcrevapm_cdn_status" <?=$cdn_status?>/> RevAPM CDN Enabled
							</div>
							<div id="mcrevapm_cdn_enabled_progress_div" class="mcrevapm_hidden">
								<img src="<?=MCREVAPM_PLUGIN_URL?>assets/img/ajax_loader.gif" />
								<span>Saving settings, please wait...</span>
							</div>
						</li>
					</ul>

<div id="mcrevapm_domain_progress_container" class="mcrevapm_hidden">
	<div class="mcrevapm_domain_progress mcrevapm_fleft">
			<img src="<?=MCREVAPM_PLUGIN_URL?>assets/img/ajax_loader.gif" />
			<span>This operation can take some minutes, please wait...</span>
	</div>
</div>