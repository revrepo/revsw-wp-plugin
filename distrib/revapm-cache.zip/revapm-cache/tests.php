<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
/////////////////////////////////////////////// tests //////////////////////////////////////////////////////////////////
/*
https://edbq.xyz/test/revapm/wp-admin/admin-ajax.php?action=mcrevapmtest&test=signup&res=ok
https://edbq.xyz/test/revapm/wp-admin/admin-ajax.php?action=mcrevapmtest&test=signup&res=error

https://edbq.xyz/test/revapm/wp-admin/admin-ajax.php?action=mcrevapmtest&test=get_api_key&res=ok
https://edbq.xyz/test/revapm/wp-admin/admin-ajax.php?action=mcrevapmtest&test=get_api_key&res=error
*/
	function mcrevapm_check_test_result($test,$res,$response){
		$ar = json_decode($response,true);
		if (
								(((int)@$ar["statusCode"] == 200) && ($res == "ok"))
								||
								(((int)@$ar["statusCode"] != 200) && ($res != "ok"))
		)
			echo "TEST $test ($res) - SUCCESS\n$response\n";
		else
			echo "TEST $test ($res) - FAILED\n$response\n";
	}

	function mcrevapm_test(){
		if (!current_user_can("manage_options")) die ("Access denied");
		include_once MCREVAPM_PLUGIN_DIR."inc/api.php";
		$test = @$_REQUEST["test"];
		$res = @$_REQUEST["res"];
		switch ($test) {
			case "signup": {
				if ( $res == "ok" ) {
					$json = '{"mcrevapm_plan":"billing-plan-developer","mcrevapm_email":"infinity-ex-' . @time() . '@narod.ru","mcrevapm_fname":"Ilia","mcrevapm_lname":"Ivanov","mcrevapm_pass":"zasada22"}';
				} else {
					$json = '{"mcrevapm_plan":"billing-plan-developer","mcrevapm_email":"infinity-ex@narod.ru","mcrevapm_fname":"Ilia","mcrevapm_lname":"Ivanov","mcrevapm_pass":"zasada22"}';
				}
				$api = new MCREVAPM_API();
				$data = json_decode( $json, true );
				$response = $api->signup( $data );
				mcrevapm_check_test_result( $test, $res, $response );
				echo $json . "\n\n";
				break;
			}
			case "get_api_key": {
				$api = new MCREVAPM_API();
				if ( $res == "ok" ) {
					$email = "infinity-ex@narod.ru";
				} else {
					$email = "test@modcoding.com";
				}
				$password = "zasada22";
				$response = $api->get_api_key( $email, $password );
				mcrevapm_check_test_result( $test, $res, $response );
				echo "email = $email password = $password\n\n";
				break;
			}
			default: {
				die ( "Error - test $test does not exist" );
			}
		}
		exit(0);
	} // mcrevapm_test

	function mcrevapm_test_all(){
		if (!current_user_can("manage_options")) die ("Access denied");
		include_once MCREVAPM_PLUGIN_DIR."inc/api.php";
		// signup
		$test = "signup";
		$res = "ok";
		$json = '{"mcrevapm_plan":"billing-plan-developer","mcrevapm_email":"infinity-ex-'.@time().'@narod.ru","mcrevapm_fname":"Ilia","mcrevapm_lname":"Ivanov","mcrevapm_pass":"zasada22"}';
		$api = new MCREVAPM_API();
		$data = json_decode($json,true);
		$response = $api->signup($data);
		mcrevapm_check_test_result($test,$res,$response);
		echo $json."\n\n";
		$res = "error";
		$json = '{"mcrevapm_plan":"billing-plan-developer","mcrevapm_email":"infinity-ex@narod.ru","mcrevapm_fname":"Ilia","mcrevapm_lname":"Ivanov","mcrevapm_pass":"zasada22"}';
		$api = new MCREVAPM_API();
		$data = json_decode($json,true);
		$response = $api->signup($data);
		mcrevapm_check_test_result($test,$res,$response);
		echo $json."\n\n";
		// get api key
		$test = "get_api_key";
		$res = "ok";
		$api = new MCREVAPM_API();
		$email = "infinity-ex@narod.ru";
		$password = "zasada22";
		$response = $api->get_api_key( $email, $password );
		mcrevapm_check_test_result( $test, $res, $response );
		echo "email = $email password = $password\n\n";
		$res = "error";
		$api = new MCREVAPM_API();
		$email = "test@modcoding.com";
		$password = "zasada22";
		$response = $api->get_api_key( $email, $password );
		mcrevapm_check_test_result( $test, $res, $response );
		echo "email = $email password = $password\n\n";
		exit(0);
	} // mcrevapm_test_all
	add_action("wp_ajax_mcrevapmtest","mcrevapm_test");
	add_action("wp_ajax_mcrevapmtest","mcrevapm_test_all");
